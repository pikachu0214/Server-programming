package com.example.hello.helloAge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloAgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloAgeApplication.class, args);
	}
}
