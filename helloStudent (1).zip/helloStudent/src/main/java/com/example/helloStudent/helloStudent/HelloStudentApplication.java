package com.example.helloStudent.helloStudent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloStudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloStudentApplication.class, args);
	}
}
